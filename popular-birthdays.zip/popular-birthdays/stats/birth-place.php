<?php
if (@$_GET['action'] == 'do-popularity') {
    global $wpdb;

    $start = now();

    global $param1;
    $p = preg_replace('#-#', ' ', $param1);
    $items = @$wpdb->get_results("SELECT * from {$wpdb->prefix}birthday_stats where birth_place like '%$p%'")[0];
    if ($items) {
        $param1 = $items->birth_place;
    }
    $birth_place = $param1;

    $items_all = @$wpdb->get_results("SELECT * from {$wpdb->prefix}birthday_stats where views > 0 order by views desc");

    (array) $arr = [];
    foreach ($items_all as $item){

        $birth_place_temp = preg_replace('# #', '-', strtolower($item->birth_place));

        if (preg_replace("# #", "-", strtolower($birth_place)) == $birth_place_temp){
            $arr[] = $item;
        }

    }

//doing birth_place_rank
    $arr = [];
    foreach ($items_all as $item){

        $birth_place_t = $item->birth_place;

        if ($birth_place_t == $birth_place){
            $arr[] = $item;
        }

    }

    $counter = 0;
    foreach ($arr as $item){
        $counter ++;
        $exists = @$wpdb->get_results("SELECT * from {$wpdb->prefix}popularity where post_id = $item->post_id")[0];
        $arr_t = ['post_id' => $item->post_id, 'birth_place_rank' => $counter];
        //        lets insert or update the popularity
        if (!$exists){
            $wpdb->insert("{$wpdb->prefix}popularity",
                $arr_t);
        }else{
            $wpdb->update("{$wpdb->prefix}popularity",
                $arr_t,
                array( "post_id" => $item->post_id )
            );
        }
    }


    $duration = date_diff2($start , now(), 'mins');
    die("Completed popularity action in {$duration} minutes.");

}

function custom_content() {

    global $post;
    global $wpdb;

    global $param1;

    $p = preg_replace('#-#', ' ', $param1);
    $items = @$wpdb->get_results("SELECT * from {$wpdb->prefix}birthday_stats where birth_place like '%$p%'")[0];
    if ($items) {
        $param1 = $items->birth_place;
    }
    $title = "People born in ".ucfirst($param1);

    $birth_place = $param1;

    $items = @$wpdb->get_results("SELECT * from {$wpdb->prefix}popularity inner join {$wpdb->prefix}birthday_stats on {$wpdb->prefix}popularity.post_id = {$wpdb->prefix}birthday_stats.post_id where birth_place_rank > 0 order by {$wpdb->prefix}popularity.birth_place_rank asc limit 50");

    (array) $arr = [];
    foreach ($items as $item){

        $birth_place_temp = preg_replace('# #', '-', strtolower($item->birth_place));

        if (preg_replace("# #", "-", strtolower($birth_place)) == $birth_place_temp){
            $arr[] = $item;
        }
    }


    $limit = 50;
    $arr = json_decode(json_encode($arr), true);
            $arr = filter_trash($arr);
            $items = limit(order_by_key($arr, 'views'), $limit * 2);
    $items = add_attachments($items, $limit, 1);
    $run_popularity = true;

    article(get_defined_vars());
}

include_once get_theme_file_path().'/single.php';
